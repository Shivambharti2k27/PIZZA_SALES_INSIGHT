# Pizza Sales Data Analysis – Power BI & SQL Project

## 📌 Problem Statement
The goal of this project is to analyze pizza sales data to gain insights into business performance and identify key trends. The project is divided into two main objectives: KPI Analysis and Chart Visualization.

## 🎯 KPI Requirements
1. **Total Revenue** – The sum of the total price of all pizza orders.  
2. **Average Order Value** – The average amount spent per order, calculated as:  
   `Average Order Value = Total Revenue / Total Orders`  
3. **Total Pizzas Sold** – The sum of the quantities of all pizzas sold.  
4. **Total Orders** – The total number of orders placed.  
5. **Average Pizzas per Order** – The average number of pizzas sold per order, calculated as:  
   `Average Pizzas per Order = Total Pizzas Sold / Total Orders`

## 📊 Charts Requirement
1. **Daily Trend for Total Orders** – Bar chart showing daily fluctuations and patterns in order volumes.  
2. **Monthly Trend for Total Orders** – Line chart highlighting peak months or periods of high order activity.  
3. **Percentage of Sales by Pizza Category** – Pie chart showing sales distribution across pizza categories.  
4. **Percentage of Sales by Pizza Size** – Pie chart for customer preferences by pizza size.  
5. **Total Pizzas Sold by Pizza Category** – Funnel chart comparing category-wise sales performance.  
6. **Top 5 Best Sellers (Revenue, Quantity, Orders)** – Bar chart identifying the most popular pizza options.  
7. **Bottom 5 Best Sellers (Revenue, Quantity, Orders)** – Bar chart highlighting underperforming pizza options.

## 🛠 Tools & Technologies Used
- SQL – Data extraction and transformation  
- Power BI – Data visualization and dashboard creation  
- Dataset – Pizza sales transactional data  

## 📈 Project Outcome
- Built an interactive Power BI dashboard to track KPIs and visualize trends.  
- Identified top-selling and low-performing products.  
- Provided insights into customer preferences for pizza size and category.  
- Enabled data-driven decision-making for promotions and inventory planning.

## 📂 How to Use
1. Import the dataset into SQL Server.  
2. Run SQL queries to prepare the data.  
3. Load the processed data into Power BI.  
4. Interact with the dashboard to explore insights.
